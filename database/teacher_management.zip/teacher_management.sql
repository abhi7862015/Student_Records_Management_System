-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 12, 2024 at 06:53 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teacher_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

DROP TABLE IF EXISTS `student_details`;
CREATE TABLE IF NOT EXISTS `student_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(260) NOT NULL,
  `last_name` varchar(260) NOT NULL,
  `email` varchar(260) NOT NULL,
  `gender` varchar(150) DEFAULT NULL,
  `status` varchar(260) NOT NULL,
  `class` varchar(150) DEFAULT NULL,
  `subject` varchar(150) DEFAULT NULL,
  `marks` varchar(150) DEFAULT NULL,
  `last_updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`id`, `first_name`, `last_name`, `email`, `gender`, `status`, `class`, `subject`, `marks`, `last_updated_date`, `created_date`, `user_id`) VALUES
(1, 'student', 'LastName', 'student1@gmail.com', 'male', 'Inactive', '9', 'Science', '80', '2024-08-12 01:38:48', '2024-08-11 20:33:45', 0),
(3, 'student', 'Lastname', 'student2@gmail.com', '', 'Active', '25', 'Computer', '02', '2024-08-12 01:33:26', '2024-08-11 21:02:06', 6),
(6, 'student', 'lastname', 'student3@gmail.com', '', 'Inactive', '20', 'Computer', '02', '2024-08-12 01:33:34', '2024-08-12 01:22:35', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_details`
--

DROP TABLE IF EXISTS `teacher_details`;
CREATE TABLE IF NOT EXISTS `teacher_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(260) NOT NULL,
  `last_name` varchar(260) NOT NULL,
  `email` varchar(260) NOT NULL,
  `gender` varchar(150) DEFAULT NULL,
  `status` varchar(260) NOT NULL,
  `attended_class` varchar(150) DEFAULT NULL,
  `subject_expertise` varchar(150) DEFAULT NULL,
  `experience` varchar(150) DEFAULT NULL,
  `last_updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher_details`
--

INSERT INTO `teacher_details` (`id`, `first_name`, `last_name`, `email`, `gender`, `status`, `attended_class`, `subject_expertise`, `experience`, `last_updated_date`, `created_date`, `user_id`) VALUES
(2, 'teacher', 'l', 'teacher1@gmail.com', 'male', 'Active', '10', 'Hindi', '52', '2024-08-12 01:00:46', '2024-08-11 20:34:10', 0),
(3, 'teacher', 'm', 'teacher3@gmail.com', 'female', 'Inactive', '10', 'Math', '2', '2024-08-12 01:13:50', '2024-08-11 23:56:49', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
CREATE TABLE IF NOT EXISTS `user_details` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(225) NOT NULL,
  `middle_name` varchar(225) NOT NULL,
  `last_name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `user_name` varchar(225) NOT NULL,
  `password` varchar(225) DEFAULT NULL,
  `user_type` varchar(30) NOT NULL,
  `user_status` varchar(30) NOT NULL,
  `set_otp` int(10) DEFAULT NULL,
  `date_added` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`user_id`, `first_name`, `middle_name`, `last_name`, `email`, `user_name`, `password`, `user_type`, `user_status`, `set_otp`, `date_added`) VALUES
(1, 'admin', 'm', 'l', 'admin1@gmail.com', 'admin1', '0e7517141fb53f21ee439b355b5a1d0a', 'Admin', 'Active', NULL, '2024-08-11 15:02:42.813025'),
(5, 'student', 'm', 'l', 'student1@gmail.com', 'student1', '098f6bcd4621d373cade4e832627b4f6', 'Student', 'Inactive', NULL, '2024-08-11 15:29:41.075236'),
(10, 'teacher', '', 'm', 'teacher2@gmail.com', 'teacher1', '4297f44b13955235245b2497399d7a93', 'Student', 'Inactive', NULL, '2024-08-11 19:31:25.071443'),
(6, 'student', 'm', 'l', 'student2@gmail.com', 'student2', '098f6bcd4621d373cade4e832627b4f6', 'Student', 'Active', NULL, '2024-08-11 15:32:06.716882'),
(11, 'parent', 'm', 'l', 'parent1@gmail.com', 'parent1', '4297f44b13955235245b2497399d7a93', 'Parent', 'Inactive', NULL, '2024-08-11 20:12:29.001238');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
